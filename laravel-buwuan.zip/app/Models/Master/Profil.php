<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Model;

class Profil extends Model
{
    protected $table = 'profil_tb';
}
