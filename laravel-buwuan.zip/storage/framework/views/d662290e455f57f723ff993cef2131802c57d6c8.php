<!-- Vendor JS Files -->
<script src="<?php echo e(asset('front/assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/waypoints/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/counterup/counterup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/venobox/venobox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/assets/vendor/aos/aos.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('front/assets/js/main.js')); ?>"></script><?php /**PATH C:\Users\pc\Documents\3. Nitip Kusnendi\tahfizh\resources\views/dewi.blade.php ENDPATH**/ ?>