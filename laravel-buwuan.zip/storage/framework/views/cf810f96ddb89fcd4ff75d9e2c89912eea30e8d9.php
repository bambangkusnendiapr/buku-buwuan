
<?php $__env->startSection('title', 'Artikel'); ?>
<?php $__env->startSection('description', "Taman tahfizh al-qur'an hamzah, tahfizh qur'an, taman tahfizh, hafizh qur'an, hafal qur'an, taman hamzah, taman qur'an, tempat menghafal al'quran"); ?>
<?php
use App\Models\Master\Profil;
$profil = Profil::find(1);
?>
<?php $__env->startSection('logo', "<?php echo e(asset('images/profil/'.$profil->profil_logo)); ?>"); ?>
<?php $__env->startSection('content'); ?>

<main id="main">

  <!-- ======= Breadcrumbs ======= -->
  <section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

      <ol>
        <li><a href="<?php echo e(route('front.index')); ?>">Home</a></li>
        <li>Artikel</li>
      </ol>
      <h2>Artikel <?php if(!empty($title)): ?> - <?php echo e($title); ?> <?php endif; ?></h2>

    </div>
  </section><!-- End Breadcrumbs -->

  <!-- ======= Blog Section ======= -->
  <section id="blog" class="blog">
    <div class="container">

      <div class="row">

        <div class="col-lg-8 entries">

          <div class="row">
            <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 d-flex align-items-stretch">
              <article class="entry">

                <div class="entry-img">
                  <img src="<?php echo e(asset('images/artikel/'.$data->artikel_gambar)); ?>" alt="" class="img-fluid">
                </div>

                <h2 class="entry-title">
                  <a href="<?php echo e(route('front.artikel.single',$data->artikel_slug)); ?>"><?php echo e($data->artikel_judul); ?></a>
                </h2>

                <div class="entry-meta">
                  <ul>
                    <li class="d-flex align-items-center"><i class="icofont-user"></i> <?php $__currentLoopData = $user->where('id', $data->penulis); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($value->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
                    <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <?php echo e(Carbon\Carbon::parse($data->artikel_tgl)->format('d/M/Y')); ?></li>
                  </ul>
                </div>

              </article><!-- End blog entry -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>

          <div class="d-flex justify-content-center">
              <?php echo $artikel->links(); ?>

          </div>

          <!-- <div class="blog-pagination">
            <ul class="justify-content-center">
              <li class="disabled"><i class="icofont-rounded-left"></i></li>
              <li><a href="#">1</a></li>
              <li class="active"><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#"><i class="icofont-rounded-right"></i></a></li>
            </ul>
          </div> -->

        </div><!-- End blog entries list -->

        <div class="col-lg-4">

          <div class="sidebar">

            <h3 class="sidebar-title">Kategori</h3>
            <div class="sidebar-item categories">
              <ul>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('artikel.kategori',$data->id)); ?>"><?php echo e($data->kategori_nama); ?> <span>(<?php echo e($data->artikel->count()); ?>)</span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>

            </div><!-- End sidebar categories-->

            <h3 class="sidebar-title">Artikel Baru</h3>
            <div class="sidebar-item recent-posts">
              <?php $__currentLoopData = $artikel_akhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="post-item clearfix entry-img">
                <img src="<?php echo e(asset('images/artikel/'.$data->artikel_gambar)); ?>" alt="" class="img-fluid">
                <h4><a href="<?php echo e(route('front.artikel.single',$data->artikel_slug)); ?>"><?php echo e($data->artikel_judul); ?></a></h4>
                <time datetime="2020-01-01"><?php echo e(Carbon\Carbon::parse($data->artikel_tgl)->format('d/M/Y')); ?></time>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div><!-- End sidebar recent posts-->

            <h3 class="sidebar-title">Tag</h3>
            <div class="sidebar-item tags">
              <ul>
                <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('artikel.tag',$data->id)); ?>"><?php echo e($data->tag_nama); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>

            </div><!-- End sidebar tags-->

          </div><!-- End sidebar -->

        </div><!-- End blog sidebar -->

      </div>

    </div>
  </section><!-- End Blog Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/front/artikel.blade.php ENDPATH**/ ?>