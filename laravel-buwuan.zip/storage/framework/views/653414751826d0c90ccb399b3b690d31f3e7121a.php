
<?php $__env->startSection('post', 'menu-open'); ?>
<?php $__env->startSection('posting', 'active'); ?>
<?php $__env->startSection('artikel', 'active'); ?>
<?php $__env->startSection('title', 'Artikel'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Artikel</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Admin</a></li>
          <li class="breadcrumb-item active">Artikel</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card card-outline card-success">
          <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="d-flex justify-content-center">
                    <?php if($artikel->artikel_gambar): ?>
                        <img id="img" src="<?php echo e(url('images/artikel/')); ?>/<?php echo e($artikel->artikel_gambar); ?>" class="figure-img img-fluid rounded" width="300px"/>
                    <?php else: ?>
                        <img id="img" src="<?php echo e(url('images/muslim.jpg')); ?>" width="200px"/>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="col-md-8">
                  <table class="table table-striped table-sm">
                    <tr>
                      <td>Judul</td>
                      <td>:</td>
                      <td><a href="<?php echo e(route('front.artikel.single', $artikel->artikel_slug)); ?>" target="_blank"><strong><?php echo e($artikel->artikel_judul); ?></strong></a></td>
                    </tr>
                    <tr>
                      <td>Kategori</td>
                      <td>:</td>
                      <td><?php echo e($artikel->kategori->kategori_nama); ?></td>
                    </tr>
                    <tr>
                      <td>Penulis</td>
                      <td>:</td>
                      <td><?php $__currentLoopData = $user->where('id', $artikel->penulis); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($value->name); ?>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                      <td>Tanggal</td>
                      <td>:</td>
                      <td><?php echo e($artikel->artikel_tgl); ?></td>
                    </tr>
                    <tr>
                      <td>Dipublish Oleh</td>
                      <td>:</td>
                      <td><?php echo e($artikel->user->name); ?></td>
                    </tr>
                    <tr>
                      <td>Komentar</td>
                      <td>:</td>
                      <td><?php echo e($artikel->komentar->count()); ?></td>
                    </tr>
                  </table>
                </div>
              </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>

    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card card-outline card-success">
          <div class="card-header">
            <h4 class="modal-title">Komentar</h4>
          </div>
          <div class="card-body">
          <table id="example1" class="table table-sm table-striped">
            <thead>
            <tr class="text-center">
              <th>#</th>
              <th>Tanggal</th>
              <th>Nama</th>
              <th>Email</th>
              <th>N HP</th>
              <th>Komentar</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $artikel->komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e(Carbon\Carbon::parse($komen->created_at)->format('d/M/Y')); ?></td>
                  <td><?php echo e($komen->komentar_nama); ?></td>
                  <td><?php echo e($komen->komentar_email); ?></td>
                  <td><?php echo e($komen->komentar_no); ?></td>
                  <td><?php echo e($komen->komentar_isi); ?></td>
                  <td>
                    <?php if (app('laratrust')->isAbleTo('komentar-delete')) : ?>
                      <a href="#" data-target="#modal-hapus<?php echo e($komen->id); ?>" class="btn btn-danger btn-sm" data-toggle="modal"><i class="fas fa-trash"></i></a>
                    <?php endif; // app('laratrust')->permission ?>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<!-- /.content -->

<!-- Modal Hapus Data -->
<?php $__currentLoopData = $artikel->komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-hapus<?php echo e($komen->id); ?>">
  <div class="modal-dialog modal-sm">
    <div class="modal-content bg-danger">
      <div class="modal-header">
        <h4 class="modal-title">Konfirmasi Hapus</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('komentar.destroy', $komen->id)); ?>" method="post" class="d-inline" id="id_form">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
          <div class="modal-body">
            <input type="hidden" value="" id="<?php echo e($komen->id); ?>">
            <p>Yakin ingin dihapus ?</p>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
            <button type="submit" class="btn btn-danger">Hapus</button>
          </div>
        </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": false, "lengthChange": true, "autoWidth": false, "scrollX": true,
      // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/admin/artikel/detail.blade.php ENDPATH**/ ?>