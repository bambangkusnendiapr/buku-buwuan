<table>
    <thead>
    <tr>
        <th>NO</th>
        <th>Nama</th>
        <th>Email</th>
        <th>L/P</th>
        <th>Panggilan</th>
        <th>Hafalan Terakhir</th>
        <th>NIK</th>
        <th>Tempat Lahir</th>
        <th>Tanggal Lahir</th>
        <th>No HP</th>
        <th>Alamat</th>
        <th>Keterangan</th>
        <th>Orangtua / WAli</th>
        <th>Hubungan</th>
        <th>No HP Ortu</th>
        <th>Alamat Ortu</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($data->user->name); ?></td>
            <td><?php echo e($data->user->email); ?></td>
            <td><?php echo e($data->santri_jk); ?></td>
            <td><?php echo e($data->santri_panggil); ?></td>
            <td><?php echo e($data->suratakhir->surat_nama); ?></td>
            <td>'<?php echo e($data->santri_nik); ?></td>
            <td><?php echo e($data->santri_lahir); ?></td>
            <td><?php echo e($data->santri_tgl); ?></td>
            <td><?php echo e($data->santri_no); ?></td>
            <td><?php echo e($data->santri_alamat); ?></td>
            <td><?php echo e($data->santri_ket); ?></td>
            <td><?php echo e($data->santri_ortu); ?></td>
            <td><?php echo e($data->santri_ortu_hubungan); ?></td>
            <td><?php echo e($data->santri_ortu_no); ?></td>
            <td><?php echo e($data->santri_ortu_alamat); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/admin/laporan/santri.blade.php ENDPATH**/ ?>