<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
    <?php if($profil->profil_logo): ?>
      <img src="<?php echo e(asset('images/profil/'.$profil->profil_logo )); ?>" alt="LOGO" class="brand-image img-circle elevation-3" style="opacity: .8">
    <?php else: ?>
      <img src="<?php echo e(asset('images/logo.png')); ?>" alt="LOGO" class="brand-image img-circle elevation-3" style="opacity: .8">
    <?php endif; ?>
    <span class="brand-text font-weight-light"><?php echo e($profil->profil_nama ? $profil->profil_nama : 'Buwuan'); ?></span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <?php if(Auth::user()->image): ?>
          <img src="<?php echo e(asset('images/')); ?>/<?php echo e(Auth::user()->image); ?>" class="img-circle elevation-2" alt="User Image">
        <?php else: ?>
          <img src="<?php echo e(asset('images/muslim.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        <?php endif; ?>
      </div>
      <div class="info">
        <a href="<?php echo e(route('profile')); ?>" class="d-block"><?php echo e(Auth::user()->name); ?></a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
              with font-awesome or any other icon font library -->
        <!-- Dashboard -->
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo e(route('buwuan')); ?>" class="nav-link <?php echo $__env->yieldContent('buwuan'); ?>">
            <i class="nav-icon fas fa-book"></i>
            <p>
              Buwuan
            </p>
          </a>
        </li>

        <li class="nav-item <?php echo $__env->yieldContent('master'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('data'); ?>">
            <i class="nav-icon fas fa-tags"></i>
            <p>
              Master Data
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('kategori.index')); ?>" class="nav-link <?php echo $__env->yieldContent('kategori'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Kategori</p>
              </a>
            </li>
            <?php if (app('laratrust')->isAbleTo('blok-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('blok.index')); ?>" class="nav-link <?php echo $__env->yieldContent('blok'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Blok</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
          </ul>
        </li>

        <?php if (app('laratrust')->hasRole('superadmin|user')) : ?>
        <li class="nav-item <?php echo $__env->yieldContent('manajemen'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('pengaturan'); ?>">
            <i class="nav-icon fas fa-cogs"></i>
            <p>
              Pengaturan
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if (app('laratrust')->hasRole('superadmin|user')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('profil.index')); ?>" class="nav-link <?php echo $__env->yieldContent('profil'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Aplikasi</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->hasRole ?>
            <?php if (app('laratrust')->hasRole('superadmin')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('user.index')); ?>" class="nav-link <?php echo $__env->yieldContent('user'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Pengguna</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('role.index')); ?>" class="nav-link <?php echo $__env->yieldContent('role'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Role</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('menu.index')); ?>" class="nav-link <?php echo $__env->yieldContent('menu'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Menu</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('permission.index')); ?>" class="nav-link <?php echo $__env->yieldContent('permission'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Permission</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->hasRole ?>
          </ul>
        </li>
        <?php endif; // app('laratrust')->hasRole ?>
        <br>
        <!-- Logout -->
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Logout
              </p>
          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\laravel-buwuan\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>