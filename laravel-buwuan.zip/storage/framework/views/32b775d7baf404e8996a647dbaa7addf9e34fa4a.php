
<?php $__env->startSection('kelas', 'active'); ?>
<?php $__env->startSection('title', 'Kelas Detail'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Santri Kelas <?php echo e($kelas->kelas_nama); ?></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Admin</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('kelas.index')); ?>">Kelas</a></li>
          <li class="breadcrumb-item active">Santri</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card card-outline card-success">
          <div class="card-body">
          <table id="example1" class="table table-sm table-striped">
            <thead>
            <tr class="text-center">
              <th>#</th>
              <th>Foto</th>
              <th>Nama</th>
              <th>Email</th>
              <th>L/P</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="text-center align-middle"><?php echo e($loop->iteration); ?></td>
                <td class="text-center align-middle">
                  <?php if($data->user->image): ?>
                      <img id="img" src="<?php echo e(url('images/santri/')); ?>/<?php echo e($data->user->image); ?>" width="50px"/>
                  <?php else: ?>
                      <img id="img" src="<?php echo e(url('images/muslim.jpg')); ?>" width="50px"/>
                  <?php endif; ?>
                </td>
                <td class="align-middle"><?php echo e($data->user->name); ?></td>
                <td class="text-center align-middle"><?php echo e($data->user->email); ?></td>
                <td class="text-center align-middle"><?php echo e($data->santri_jk); ?></td>
                <td class="text-center align-middle">
                  <?php if (app('laratrust')->isAbleTo('santri-buku-read')) : ?>
                  <a href="<?php echo e(route('santri.show', $data->id)); ?>" class="btn btn-success btn-sm">buku</a>
                  <?php endif; // app('laratrust')->permission ?>
                  <a href="#" data-target="#modal-edit<?php echo e($data->id); ?>" class="btn btn-primary btn-sm" data-toggle="modal">detail</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<!-- /.content -->

<?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-edit<?php echo e($data->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h4 class="modal-title">Detail Santri</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
          <?php if($data->user->image): ?>
            <img src="<?php echo e(asset('images/')); ?>/<?php echo e($data->user->image); ?>" class="img-circle" width="80"/><br>
          <?php endif; ?>

          <div class="row">
            <div class="col-md-6">
              <strong>Nama</strong>
                <p class="text-muted"><?php echo e($data->user->name); ?></p>

                <strong>Email</strong>
                <p class="text-muted"><?php echo e($data->user->email); ?></p>

                <strong>Nama Panggilan</strong>
                <p class="text-muted"><?php echo e($data->santri_panggil); ?></p>

                <strong>NIK</strong>
                <p class="text-muted"><?php echo e($data->santri_nik); ?></p>

                <strong>Tempat Lahir</strong>
                <p class="text-muted"><?php echo e($data->santri_lahir); ?></p>

                <strong>Tanggal Lahir</strong>
                <p class="text-muted"><?php echo e($data->santri_tgl); ?></p>

                <strong>Jenis Kelamin</strong>
                <p class="text-muted"><?php echo e($data->santri_jk); ?></p>
            </div>

            <div class="col-md 6">
                <strong>Kelas</strong>
                <p class="text-muted"><?php echo e($data->kelas->kelas_nama); ?></p>
                
                <strong>Umur Saat Daftar</strong>
                <p class="text-muted"><?php echo e($data->santri_umur); ?></p>

                <strong>Hafalan Saat Daftar</strong>
                <p class="text-muted"><?php echo e($data->santri_hafal); ?></p>

                <strong>Hafalan Saat Ini</strong>
                <p class="text-muted"><?php echo e($data->suratakhir->surat_nama); ?></p>

                <strong>No HP/WA</strong>
                <p class="text-muted"><?php echo e($data->santri_no); ?></p>

                <strong>Alamat</strong>
                <p class="text-muted"><?php echo e($data->santri_alamat); ?></p>

                <strong>Keterangan</strong>
                <p class="text-muted"><?php echo e($data->santri_ket); ?></p>
            </div>
          </div>

        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- /.modal -->

<!-- Modal Hapus Data -->
<?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-hapus<?php echo e($data->id); ?>">
  <div class="modal-dialog modal-sm">
    <div class="modal-content bg-danger">
      <div class="modal-header">
        <h4 class="modal-title">Konfirmasi Hapus</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('santri.destroy', $data->id)); ?>" method="post" class="d-inline" id="id_form">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
          <div class="modal-body">
            <input type="hidden" value="" id="<?php echo e($data->id); ?>">
            <p>Yakin ingin dihapus ?</p>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
            <button type="submit" class="btn btn-danger">Hapus</button>
          </div>
        </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": false, "lengthChange": true, "autoWidth": false, "scrollX": true,
      // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/admin/kelas/show.blade.php ENDPATH**/ ?>