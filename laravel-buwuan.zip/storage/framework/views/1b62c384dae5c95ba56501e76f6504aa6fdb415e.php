<aside class="main-sidebar sidebar-dark-success elevation-4">
  <!-- Brand Logo -->
  <a href="../../index3.html" class="brand-link">
    <img src="<?php echo e(asset('images/profil/'.$profil->profil_logo )); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light"><?php echo e($profil->profil_nama); ?></span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <?php if(!Auth::guest()): ?>
    <!-- Sidebar user (optional) -->
    <?php if (app('laratrust')->hasRole('admin|santri|user')) : ?>
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <?php if(Auth::user()->image): ?>
          <?php if (app('laratrust')->hasRole('admin')) : ?>
          <img src="<?php echo e(asset('images/guru/')); ?>/<?php echo e(Auth::user()->image); ?>" class="img-circle elevation-2" alt="User Image"/>
          <?php endif; // app('laratrust')->hasRole ?>
          <?php if (app('laratrust')->hasRole('santri|user')) : ?>
          <img src="<?php echo e(asset('images/santri/')); ?>/<?php echo e(Auth::user()->image); ?>" class="img-circle elevation-2" alt="User Image"/>
          <?php endif; // app('laratrust')->hasRole ?>
        <?php else: ?>
          <img src="<?php echo e(asset('images/muslim.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        <?php endif; ?>
      </div>
      <div class="info">
        <a href="<?php echo e(route('profile')); ?>" class="d-block"><?php echo e(Auth::user()->name); ?></a>
      </div>
    </div>
    <?php endif; // app('laratrust')->hasRole ?>
    <?php if (app('laratrust')->hasRole('superadmin')) : ?>
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <?php if(Auth::user()->image): ?>
          <img src="<?php echo e(asset('images/guru/')); ?>/<?php echo e(Auth::user()->image); ?>" class="img-circle elevation-2" alt="User Image"/>
        <?php else: ?>
          <img src="<?php echo e(asset('images/muslim.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        <?php endif; ?>
      </div>
      <div class="info">
        <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
      </div>
    </div>
    <?php endif; // app('laratrust')->hasRole ?>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
              with font-awesome or any other icon font library -->
        <!-- Dashboard -->
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>
        
        <?php if (app('laratrust')->isAbleTo('pendaftaran-read')) : ?>
        <li class="nav-item">
          <a href="<?php echo e(route('pendaftaran')); ?>" class="nav-link <?php echo $__env->yieldContent('pendaftaran'); ?>">
            <i class="nav-icon fas fa-clipboard-list"></i>
            <p>
              Pendaftaran
            </p>
          </a>
        </li>
        <?php endif; // app('laratrust')->permission ?>
        <?php if (app('laratrust')->isAbleTo('santri-read')) : ?>
        <li class="nav-item">
          <a href="<?php echo e(route('santri.index')); ?>" class="nav-link <?php echo $__env->yieldContent('santri'); ?>">
            <i class="nav-icon fas fa-child"></i>
            <p>
              Santri
            </p>
          </a>
        </li>
        <?php endif; // app('laratrust')->permission ?>
        <?php if (app('laratrust')->isAbleTo('guru-read')) : ?>
        <li class="nav-item">
          <a href="<?php echo e(route('guru.index')); ?>" class="nav-link <?php echo $__env->yieldContent('guru'); ?>">
            <i class="nav-icon fas fa-chalkboard-teacher"></i>
            <p>
              Guru
            </p>
          </a>
        </li>
        <?php endif; // app('laratrust')->permission ?>
        <li class="nav-item <?php echo $__env->yieldContent('pembelajaran'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('belajar'); ?>">
            <i class="fas fa-table nav-icon"></i>
            <p>
              Pembelajaran
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if (app('laratrust')->isAbleTo('kelas-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('kelas.index')); ?>" class="nav-link <?php echo $__env->yieldContent('kelas'); ?>">
                
                <i class="far fa-circle nav-icon"></i>
                <p>Kelas</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('nilai-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('nilai.index')); ?>" class="nav-link <?php echo $__env->yieldContent('nilai'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Nilai</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
          </ul>
        </li>
        <?php if (app('laratrust')->hasRole('superadmin|admin')) : ?>
        <li class="nav-item <?php echo $__env->yieldContent('post'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('posting'); ?>">
            <i class="nav-icon far fa-newspaper"></i>
            <p>
              Artikel
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if (app('laratrust')->isAbleTo('artikel-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('artikel.index')); ?>" class="nav-link <?php echo $__env->yieldContent('artikel'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Artikel</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('kategori-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('kategori.index')); ?>" class="nav-link <?php echo $__env->yieldContent('kategori'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Kategori</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('tag-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('tag.index')); ?>" class="nav-link <?php echo $__env->yieldContent('tag'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Tag</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
          </ul>
        </li>
        <li class="nav-item <?php echo $__env->yieldContent('manajemen'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('pengaturan'); ?>">
            <i class="nav-icon fas fa-cogs"></i>
            <p>
              Pengaturan
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <?php if (app('laratrust')->isAbleTo('profil-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('profil.index')); ?>" class="nav-link <?php echo $__env->yieldContent('profil'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Profil</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('pengguna-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('user.index')); ?>" class="nav-link <?php echo $__env->yieldContent('user'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Pengguna</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('role-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('role.index')); ?>" class="nav-link <?php echo $__env->yieldContent('role'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Role</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('menu-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('menu.index')); ?>" class="nav-link <?php echo $__env->yieldContent('menu'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Menu</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
            <?php if (app('laratrust')->isAbleTo('permission-read')) : ?>
            <li class="nav-item">
              <a href="<?php echo e(route('permission.index')); ?>" class="nav-link <?php echo $__env->yieldContent('permission'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Permission</p>
              </a>
            </li>
            <?php endif; // app('laratrust')->permission ?>
          </ul>
        </li>
        <?php endif; // app('laratrust')->hasRole ?>
        <!-- Logout -->
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Logout
              </p>
          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
    </nav>
    <?php endif; ?>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>