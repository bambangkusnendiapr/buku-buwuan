<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-index', [])->html();
} elseif ($_instance->childHasBeenRendered('rHG83Y6')) {
    $componentId = $_instance->getRenderedChildComponentId('rHG83Y6');
    $componentTag = $_instance->getRenderedChildComponentTagName('rHG83Y6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rHG83Y6');
} else {
    $response = \Livewire\Livewire::mount('contact-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('rHG83Y6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-index>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script>
  $(function () {
    $('#tombol').on('click', function() {
        alert('ok');
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\laravel-buwuan\resources\views/home.blade.php ENDPATH**/ ?>