<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>Version</b> 1.0
  </div>
  <strong>Copyright &copy; 2021 </strong>Develop By <a target="_blank" href="https://www.facebook.com/bambang.kusnendiapr.7/">BamKApr</a>
</footer><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\laravel-buwuan\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>