
<?php $__env->startSection('pendaftaran', 'active'); ?>
<?php $__env->startSection('title', 'Pendafatran'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Pendafatran</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Admin</a></li>
          <li class="breadcrumb-item active">Pendaftaran</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card card-outline card-success">
          <div class="card-header">
            Konfirmasi Pendafatran

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
            </div>
          </div>
          <div class="card-body">
          <table id="example1" class="table table-sm table-striped">
            <thead>
            <tr class="text-center">
              <th>#</th>
              <th>Gambar</th>
              <th>Nama</th>
              <th>Umur</th>
              <th>Jenis Kelamin</th>
              <th>No HP/WA</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="align-middle text-center"><?php echo e($loop->iteration); ?></td>
                <td>
                  <?php if($data->user->image): ?>
                    <img src="<?php echo e(asset('images/')); ?>/<?php echo e($data->user->image); ?>" class="img-circle" width="80"/>
                  <?php endif; ?>
                </td>
                <td><?php echo e($data->user->name); ?></td>
                <td><?php echo e($data->santri_umur); ?></td>
                <td><?php echo e($data->santri_jk); ?></td>
                <td><?php echo e($data->santri_no); ?></td>
                <td>
                  <a href="#" data-target="#modal-edit<?php echo e($data->id); ?>" class="btn btn-warning btn-sm" data-toggle="modal">detail</a>
                  <a href="#" data-target="#modal-konfirmasi<?php echo e($data->id); ?>" class="btn btn-success btn-sm" data-toggle="modal">konfirmasi</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<!-- /.content -->

<?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-edit<?php echo e($data->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h4 class="modal-title">Detail Santri</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
          <?php if($data->user->image): ?>
            <img src="<?php echo e(asset('images/')); ?>/<?php echo e($data->user->image); ?>" class="img-circle" width="80"/><br>
          <?php endif; ?>

          <div class="row">
            <div class="col-md-6">
              <strong>Nama</strong>
                <p class="text-muted"><?php echo e($data->user->name); ?></p>

                <strong>Email</strong>
                <p class="text-muted"><?php echo e($data->user->email); ?></p>

                <strong>Umur</strong>
                <p class="text-muted"><?php echo e($data->santri_umur); ?></p>

                <strong>Hafalan</strong>
                <p class="text-muted"><?php echo e($data->santri_hafal); ?></p>

                <strong>L/P</strong>
                <p class="text-muted"><?php echo e($data->santri_jk); ?></p>

                <strong>No HP/WA</strong>
                <p class="text-muted"><?php echo e($data->santri_no); ?></p>
            </div>

            <div class="col-md 6">
              <strong>Panggilan</strong>
                <p class="text-muted"><?php echo e($data->santri_panggil); ?></p>

                <strong>NIK</strong>
                <p class="text-muted"><?php echo e($data->santri_nik); ?></p>

                <strong>Tempat Lahir</strong>
                <p class="text-muted"><?php echo e($data->santri_lahir); ?></p>

                <strong>Tanggal Lahir</strong>
                <p class="text-muted"><?php echo e($data->santri_tgl); ?></p>

                <strong>Alamat</strong>
                <p class="text-muted"><?php echo e($data->santri_alamat); ?></p>

                <strong>Keterangan</strong>
                <p class="text-muted"><?php echo e($data->santri_ket); ?></p>
            </div>
          </div>

        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- /.modal -->

<!-- Modal Konfirmasi Data -->
<?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-konfirmasi<?php echo e($data->id); ?>">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header bg-success">
        <h4 class="modal-title">Konfirmasi Santri</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('konfirmasi', $data->id)); ?>" method="post" class="d-inline" id="id_form">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
          <div class="modal-body">
            <input type="hidden" name="user_id" value="<?php echo e($data->user->id); ?>">
            <p>Konfirmasi penerimaan santri <strong><?php echo e($data->user->name); ?></strong>?</p>
            <div class="form-group">
              <label for="kelas">Pilih Kelas</label>
              <select name="kelas" id="kelas" class="form-control">
                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->kelas_nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
            <button type="submit" class="btn btn-success">Konfirmasi</button>
          </div>
        </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": false, "lengthChange": true, "autoWidth": false, "scrollX": true,
      // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/admin/pendaftaran/index.blade.php ENDPATH**/ ?>