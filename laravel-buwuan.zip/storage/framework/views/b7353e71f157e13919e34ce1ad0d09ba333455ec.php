<table>
  <thead>
    <tr>
      <th>Nomor</th>
      <th>id_kategori</th>
      <th>nama</th>
      <th>blok</th>
      <th>jumlah</th>
      <th>keterangan</th>
    </tr>
  </thead>
</table><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\laravel-buwuan\resources\views/admin/laporan/template.blade.php ENDPATH**/ ?>