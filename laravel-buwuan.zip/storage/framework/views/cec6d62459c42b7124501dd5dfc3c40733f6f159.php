
<?php $__env->startSection('santri', 'active'); ?>
<?php $__env->startSection('title', 'Buku Santri'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Buku Santri <strong class="font-italic"><?php echo e($santri->user->name); ?></strong></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Admin</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('santri.index')); ?>">Santri</a></li>
          <li class="breadcrumb-item active">Buku</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card card-outline card-success">
          <?php if (app('laratrust')->isAbleTo('santri-buku-create')) : ?>
          <div class="card-header">            
            <a href="<?php echo e(route('santri.buku.create', $santri->id)); ?>" class="btn btn-success card-title"><i class="fas fa-plus"></i> Tambah Tahfizh</a>            
          </div>
          <?php endif; // app('laratrust')->permission ?>
          <div class="card-body">
          <table id="example1" class="table table-sm table-striped">
            <thead>
            <tr class="text-center">
              <th>#</th>
              <th>Tanggal</th>
              <th>Guru</th>
              <th>Jilid</th>
              <th>Halaman</th>
              <th>Murajaah</th>
              <th>Ziyadah</th>
              <th>Nilai</th>
              <th>Keterangan</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->buku_tgl); ?></td>
                <td><?php echo e($data->guru->user->name); ?></td>
                <td><?php echo e($data->buku_jilid); ?></td>
                <td><?php echo e($data->buku_halaman); ?></td>
                <td><?php echo e($data->buku_murajaah); ?></td>
                <td><?php echo e($data->buku_ziyadah); ?></td>
                <td><?php echo e($data->nilai->nilai_nama); ?></td>
                <td><?php echo e($data->buku_ket); ?></td>
                <td>
                  <?php if (app('laratrust')->isAbleTo('santri-buku-delete')) : ?>
                    <a href="#" data-target="#modal-hapus<?php echo e($data->id); ?>" class="btn btn-danger btn-sm" data-toggle="modal">hapus</a>
                  <?php endif; // app('laratrust')->permission ?>
                  <?php if (app('laratrust')->isAbleTo('santri-buku-update')) : ?>
                    <a href="<?php echo e(route('santri.buku.edit', $data->id)); ?>" class="btn btn-warning btn-sm">edit</a>
                  <?php endif; // app('laratrust')->permission ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>

    <form action="<?php echo e(route('santri.surat.juz', $santri->id)); ?>" method="POST">
      <?php echo method_field('PATCH'); ?>
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-12">
          <!-- Default box -->
          <div class="card card-success">
            <div class="card-header">            
              <h3 class="card-title">Hafalan Surat dan Juz Al-Qur'an</h3>           
            </div>
            <div class="card-body">
              <div class="form-group">
                <label>Pilih Juz Yang Sudah Dihafal</label>
                <div class="select2-success">
                  <select class="select2" name="juz[]" multiple="multiple" data-placeholder="Pilih Juz" data-dropdown-css-class="select2-purple" style="width: 100%;">
                    <?php $__currentLoopData = $juz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"
                      <?php $__currentLoopData = $santri->juz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($data->id == $value->id): ?>
                        selected
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ><?php echo e($data->juz_nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label>Pilih Surat Yang Sudah Dihafal</label>
                <div class="select2-primary">
                  <select class="select2" name="surat[]" multiple="multiple" data-placeholder="Pilih Surat" data-dropdown-css-class="select2-purple" style="width: 100%;">
                    <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"
                      <?php $__currentLoopData = $santri->surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($data->id == $value->id): ?>
                        selected
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ><?php echo e($loop->iteration); ?>. <?php echo e($data->surat_nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="row">
                <div class="col-md-7">
                  <div class="form-group">
                    <label>Hafalan Surat Terakhir</label>
                    <select class="form-control select2bs4" name="surat_akhir" style="width: 100%;">
                      <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>" <?php echo e($data->id == $santri->surat_id ? 'selected':''); ?>><?php echo e($loop->iteration); ?>. <?php echo e($data->surat_nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-5">
                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg w-100 mt-4">Simpan Hafalan</button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </form>
  </div>
</section>
<!-- /.content -->

<!-- Modal Hapus Data -->
<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-hapus<?php echo e($data->id); ?>">
  <div class="modal-dialog modal-sm">
    <div class="modal-content bg-danger">
      <div class="modal-header">
        <h4 class="modal-title">Konfirmasi Hapus</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('santri.buku.delete', $data->id)); ?>" method="post" class="d-inline" id="id_form">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
          <div class="modal-body">
            <input type="hidden" value="" id="<?php echo e($data->id); ?>">
            <p>Yakin ingin dihapus ?</p>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
            <button type="submit" class="btn btn-danger">Hapus</button>
          </div>
        </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
<!-- SweetAlert2 -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": false, "lengthChange": true, "autoWidth": false, "scrollX": true,
      // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });

    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/admin/santri/buku.blade.php ENDPATH**/ ?>