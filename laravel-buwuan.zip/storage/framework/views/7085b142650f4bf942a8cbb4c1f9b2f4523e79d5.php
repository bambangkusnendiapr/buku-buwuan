<div>
    <button id="tombol">klik</button>

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if($statusUpdate): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-update', [])->html();
} elseif ($_instance->childHasBeenRendered('4qhy94W')) {
    $componentId = $_instance->getRenderedChildComponentId('4qhy94W');
    $componentTag = $_instance->getRenderedChildComponentTagName('4qhy94W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4qhy94W');
} else {
    $response = \Livewire\Livewire::mount('contact-update', []);
    $html = $response->html();
    $_instance->logRenderedChild('4qhy94W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-update>
    <?php else: ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-create', [])->html();
} elseif ($_instance->childHasBeenRendered('Qvs7X5k')) {
    $componentId = $_instance->getRenderedChildComponentId('Qvs7X5k');
    $componentTag = $_instance->getRenderedChildComponentTagName('Qvs7X5k');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Qvs7X5k');
} else {
    $response = \Livewire\Livewire::mount('contact-create', []);
    $html = $response->html();
    $_instance->logRenderedChild('Qvs7X5k', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-create>
    <?php endif; ?>

    <hr>

    <div class="row">
        <div class="col">
            <select wire:model="paginate" name="" id="" class="form-control form-control-sm w-auto">
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="15">15</option>
            </select>
        </div>

        <div class="col">
            <select wire:model="cari" name="" id="" class="form-control form-control-sm w-auto">
                <option value="all">all</option>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->kategori_nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col">
            <input wire:model="search" type="text" class="form-control form-control-sm w-100" placeholder="Search">
        </div>
    </div>

    <hr>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Kategori</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($contact->name); ?></td>
                <td><?php echo e($contact->phone); ?></td>
                <td><?php echo e($contact->kategori->kategori_nama); ?></td>
                <td>
                    <button wire:click="getContact(<?php echo e($contact->id); ?>)" class="btn btn-sm btn-info">Edit</button>
                    <button wire:click="destroy(<?php echo e($contact->id); ?>)" class="btn btn-sm btn-danger">Hapus</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <nav aria-label="Page navigation example">
        <?php echo e($contacts->links()); ?>

    </nav>
</div>
<?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\laravel-buwuan\resources\views/livewire/contact-index.blade.php ENDPATH**/ ?>