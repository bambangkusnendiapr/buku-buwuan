<table>
    <thead>
    <tr>
        <th>NO</th>
        <th>Nama</th>
        <th>Email</th>
        <th>L/P</th>
        <th>Hafalan</th>
        <th>No HP/WA</th>
        <th>Tempat Lahir</th>
        <th>Tanggal Lahir</th>
        <th>Alamat</th>
        <th>Keterangan</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($data->user->name); ?></td>
            <td><?php echo e($data->user->email); ?></td>
            <td><?php echo e($data->guru_jk); ?></td>
            <td><?php echo e($data->suratakhir->surat_nama); ?></td>
            <td><?php echo e($data->guru_no); ?></td>
            <td><?php echo e($data->guru_lahir); ?></td>
            <td><?php echo e($data->guru_tgl); ?></td>
            <td><?php echo e($data->guru_alamat); ?></td>
            <td><?php echo e($data->guru_ket); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\pc\Documents\5. Nitip Kusnendi\tahfizh\resources\views/admin/laporan/guru.blade.php ENDPATH**/ ?>