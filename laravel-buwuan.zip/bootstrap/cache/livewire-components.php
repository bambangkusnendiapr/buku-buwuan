<?php return array (
  'buwuan-index' => 'App\\Http\\Livewire\\BuwuanIndex',
  'contact-create' => 'App\\Http\\Livewire\\ContactCreate',
  'contact-index' => 'App\\Http\\Livewire\\ContactIndex',
  'contact-update' => 'App\\Http\\Livewire\\ContactUpdate',
);